//
//  HRVParser.swift
//  HRVMonitor WatchKit Extension
//
//  Created by Trevor Morris on 14/10/2021.
//

import Foundation

class HRVParser
{
    func readFile(fname : String) -> [HRVEntry]
    {
        return
    }
}
