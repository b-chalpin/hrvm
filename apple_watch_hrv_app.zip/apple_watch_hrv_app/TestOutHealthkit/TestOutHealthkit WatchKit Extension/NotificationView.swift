//
//  NotificationView.swift
//  TestOutHealthkit WatchKit Extension
//
//  Created by EWU Team5 on 9/27/21.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
