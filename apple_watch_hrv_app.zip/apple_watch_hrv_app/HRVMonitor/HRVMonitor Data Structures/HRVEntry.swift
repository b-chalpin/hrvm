//
//  HRVEntry.swift
//  HRVMonitor WatchKit Extension
//
//  Created by Trevor Morris on 13/10/2021.
//

import Foundation

class HRVEntry
{
    var bpm: Double
    
    init(bpm: Double)
    {
        self.bpm = bpm
    }
}
